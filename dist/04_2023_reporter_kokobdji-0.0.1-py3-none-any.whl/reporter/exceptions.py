class NotFound(Exception):
    pass


class SymbolMistakes(Exception):
    pass
