START: str = 'start.log'
END: str = 'end.log'
ABBREVIATIONS: str = 'abbreviations.txt'
TIME_FORMATTER: str = '%H:%M:%S.%f'
NAME_SLICE = slice(1, None)
TIME_SLICE = slice(3, -3)
TIME_FORMATTER_SLICE = slice(0, 3)
